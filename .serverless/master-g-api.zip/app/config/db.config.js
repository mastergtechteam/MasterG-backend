module.exports = {
  url: "mongodb://0.0.0.0:27017/bezkoder_db"
};
